library(pwr)
library(ggpubr)
library(rcompanion)
library(tidyr)
library(ez)


dirstudio <- dirname(rstudioapi::getSourceEditorContext()$path)
setwd(dirstudio)

# Se guarda el nombre del archivo y se abre con File.path
basename <- "datos-Forma04.csv"
file <- file.path(dirstudio, basename)
datos <- read.csv(file = file, encoding = "UTF-8")



# Pregunta 1 --------------------------------------------------------------


'
En el estudio realizado entre 2007 y 2009, los cient�ficos determinaron que existen cambios
significativos de peso entre estaciones del año en espec�menes de la especie Adelia.

Realice un an�lisis inferencial con 95% de confianza, explicando y justificando paso a paso
el procedimiento seguido (hip�tesis contrastadas, prueba estad�stica usada, verificaci�n de condiciones,
etc.), que determine si la aseveraci�n enunciada es respaldada por los datos. Si los datos no permiten un
an�lisis par�metro directamente, utilice alguna transformaci�n para adecuarlos.

Ya que el porcentaje de confianza es del 95%, se sabe que alfa es igual a 0.05

Ui: Media de peso en invierno
Uv: Media de peso en verano
Up: Media de peso en primavera
Uo: Media de peso en oto�o


H0: No existen cambios significativos en la media de peso entre las estacios del a�o de la especie Adelia (Ui = Uv = Up = Uo)
H1: Existen cambios significativos en la media de peso entre las estaciones del a�o de la especie Adelia (Ui != Uv != Up != Uo)

Condiciones a verificar para aplicar Anova
1. La variable dependiente tiene escala de intervalos iguales.
2. Las mediciones son independientes al interior de cada grupo.
3. Se puede suponer razonablemente que la(s) poblaci�n(es) de origen sigue(n) una distribuci�n normal.
4. La matriz de varianzas-covarianzas es esf�ricas.

Verificaciones:
1. Se cumple ya que los datos poseen escala unitaria.
2. Se asume independencia de los datos debido a su origen.
3.
'

datos.adelia <- subset(datos, datos$Especie == "Adelia")
datos.adelia$ID_ave <- NULL
datos.adelia$Especie <- NULL
datos.adelia$Largo_pico <- NULL
datos.adelia$Profundidad_pico <- NULL
datos.adelia$Largo_aleta <- NULL
datos.adelia$Sexo <- NULL
datos.adelia$Ano <- NULL
datos.adelia$Isla <- NULL

dl1 <- gather(
  data = datos.adelia,
  key = "Estaciones",
  value = "Pesos"
)

# Graficamos con un gr�fico de cajas
g1 <- ggboxplot(
  dl1,
  x = "Estaciones", y = "Pesos",
  xlab = "Estaciones",
  ylab = "Pesos",
  color = "Estaciones",
  add = "jitter",
  add.params = list(color = "Estaciones", fill = "Estaciones")
)
print(g1)


'
Viendo el gr�fico de cajas podemos notar que existen muchos valores at�picos en 
todas las estaciones del a�o, por lo que no se considera que tenga una distribuci�n
normal. Por enunciado se transformar�n estos datos para llevarlos a una distribuci�n
normal, usando la escalera de potencias de Tukey.
'

datos.adelia.invierno <- datos.adelia$Peso_invierno
datos.adelia.verano <- datos.adelia$Peso_verano
datos.adelia.otonio <- datos.adelia$Peso_otono
datos.adelia.primavera <- datos.adelia$Peso_primavera

Pesos <- c(datos.adelia.invierno, datos.adelia.verano, datos.adelia.otonio, datos.adelia.primavera)

Sujeto <- rep(1:18, 4)

Estaciones <- c(rep("Peso Invierno", 18),
                rep("Peso Verano", 18),
                rep("Peso Oto�o", 18),
                rep("Peso Primavera", 18))

Estaciones <- factor(Estaciones)
Sujeto <- factor(Sujeto)

frame <- data.frame(Sujeto, Estaciones, Pesos)

transformacion <- transformTukey(frame$Pesos,
                                 start = -4,
                                 end = 4,
                                 int = 0.001,
                                 returnLambda = TRUE)
print(transformacion)

'
Segun la funci�n transformTukey, el lambda �ptimo a usar es 0.228, por lo que 
se procede a transformar los datos con este valor.
'

lambda_optimo <- frame$Pesos ** 0.228

transformacion_optima <- data.frame(frame, lambda_optimo)

gto <- ggscatter(transformacion_optima, 
                 x = "Pesos", 
                 y = "lambda_optimo", 
                 color = "blue", 
                 xlab = "solucion", 
                 ylab = "lambda = 0.228") + rotate_x_text(45)

print(gto)

'
Teniendo los datos transformados se cumple la condici�n 3 para aplicar ANOVA

4. No se sabe si se cumple la condici�n de esfericidad, a�n cuando se cumple las dem�s condiciones. 
Se prosigue con mucha cautela, considerando un nivel de significaci�n alfa = 0,01.

Se procede a aplicar ANOVA
'

ez.aov <- ezANOVA(
  data = transformacion_optima, 
  dv = lambda_optimo,
  within = Estaciones,
  wid = Sujeto,
  return_aov = TRUE
)
print(ez.aov)

'
Viendo el resultado de la prueba de Mauchly, se tienen un p-valor de 0.7910557
que es mayor a 0.01, por lo que no existe evidencia suficiente para rechazar H0, 
s� se cumple la condici�n de esfericidad. Debido a esto no hay que aplicar correciones.
El p-valor de ANOVA es de 0.6465468 lo que es mayor a 0.05, por lo que no existe evidencia
suficiente para rechazar H0, as� que se cncluye que no existen diferencias significativas en el promedio
de pesos de los ping�inos en las distintas estaciones del a�o.
'


# Pregunta 2 --------------------------------------------------------------

'
Cient�ficos aseguran que mediciones realizadas entre 2007 y 2009 sugieren que existen diferencias
en el largo de las aletas entre las tres especies de ping�inos estudiadas.

Realice un an�lisis inferencial con 95% de confianza, explicando y justificando paso a
paso el procedimiento seguido (hip�tesis contrastadas, prueba estad�stica usada, verificaci�n de
condiciones, etc.), que determine si la aseveraci�n enunciada es respaldada por los datos. Si los datos
no permiten un an�lisis par�metro directamente, utilice alguna alternativa no param�trica.

Ya que el porcentaje de confianza es del 95%, se sabe que alfa es igual a 0.05
'

datos.copia <- datos
datos.copia$ID_ave <- NULL
datos.copia$Largo_pico <- NULL
datos.copia$Profundidad_pico <- NULL
datos.copia$Sexo <- NULL
datos.copia$Ano <- NULL
datos.copia$Isla <- NULL
datos.copia$Peso_invierno <- NULL
datos.copia$Peso_verano <- NULL
datos.copia$Peso_otono <- NULL
datos.copia$Peso_primavera <- NULL


#Procedemos a graficar con un gr�fico de cajas
g2 <- ggboxplot(
  datos.copia,
  x = "Especie", y = "Largo_aleta",
  xlab = "Especie",
  ylab = "Largo_aleta",
  color = "Especie",
  add = "jitter",
  add.params = list(color = "Especie", fill = "Especie")
)
print(g2)

'
Viendo el gr�fico de cajas se puede notar que existen muchos valores at�picos
en las tres especies por lo que se asume que no siguen una distribucion normal.
Se proceder� a usar una opci�n no par�metrica para muestras independientes (Kruskal-Wallis).

Condiciones de Kruskal-Wallis:
1. La variable independiente debe tener a lo menos dos niveles.
2. La escala de la variable dependiente debe ser, a lo menos, ordinal.
3. Las observaciones son independientes entre s�.
4. Las distribuciones de las observaciones de cada grupo deben tener la misma forma.


Verificaciones:
1. La variable independiente (Especies) tiene tres niveles.
2. La escala de la variable dependiente es ordinal ya que se puede ordenar de mayor a menor,
por ejemplo: 198 es menor que 204 y mayor que 195.
3. Se puede asumir independencia de las observaciones debido al origen de los datos.

Ua: Promedio de largo de aletas de ping�inos Adelia
Uj: Promedio de largo de aletas de ping�inos Juanito
Ub: Promedio de largo de aletas de ping�inos Barbijo

H0: El largo promedio de las aletas es similar entre las tres especies de ping�inos. (Ua = Uj = Ub)
H1: El largo promedio de las aletas es diferente en al menos dos de las especies de ping�inos (Ua != Uj != Ub)
'


Adelia <- subset(datos.copia, datos.copia$Especie == "Adelia")
Juanito <- subset(datos.copia, datos.copia$Especie == "Juanito")
Barbijo <- subset(datos.copia, datos.copia$Especie == "Barbijo")

Largo.Adelia <- Adelia$Largo_aleta
Largo.Juanito <- Juanito$Largo_aleta
Largo.Barbijo <- Barbijo$Largo_aleta

Largos <- c(Largo.Adelia, Largo.Juanito, Largo.Barbijo)
Sujeto <- rep(1:50)

Especies <- c(rep("Adelia", length(Largo.Adelia)),
              rep("Juanito", length(Largo.Juanito)),
              rep("Barbijo", length(Largo.Barbijo)))

Largos <- factor(Largos)
Especies <- factor(Especies)

frame <- data.frame(Largos, Especies)

test <- kruskal.test(Largos ~ Especies, data = frame)
print(test)

'
Con un p-valor de 0.4385 que es menor a alfa igual a 0.05, existe evidencia suficiente
para rechazar H0 en favor de H1. Almenos dos especies de ping�inos estudiadas tienen un
promedio de largo de aleta distinto.
'



# Pregunta 3 --------------------------------------------------------------

'
Tras largos d�as de pandemia, y debido a todas las repercusiones en el bienestar 
social y econ�mico sobre la sociedad, la organizaci�n independiente "Sonr�e" desea 
realizar dos encuestas para reflejar la opini�n de los chilenos respecto a la reactivaci�n 
econ�mica post pandemia de EEUU que podr�a influenciar directamente en la econom�a del pa�s, 
conociendo su opini�n en dos momentos distintos, antes y despu�s de ser anunciado que los
negocios y empresas que hab�an sido detenidos durante la pandemia, ahora ser�an devueltos
a su funcionamiento cotidiano.

La prueba que se realizar� ser� la de U de Mann-Whitney, dadas las caracter�sticas de la 
escala de la variable dependiente (ranking).

- Variable independiente: Expectativa (dado un ranking)
- Factor: d�a en que la encuesta es realizada
- Niveles: antes y despu�s de conocerse la apertura de los negocios y empresas de EE. UU.

- H0: Las muestran vienen de la misma poblaci�n
- H1: las poblaciones difieren al menos en una medida de tendencia central

En caso de que efectivamente aumenten las expectativas dado el conocimiento de la 
reactivaci�n de los negocios, sobre la activaci�n de la econom�a, se dar�a el caso H1, 
mientras que en caso de que no aumenten las expectativas, la corporaci�n buscar� formas 
de ayudar con la psiquis de la poblaci�n que podr�a verse abrumada tras la pandemia y las 
constantes noticias negativas.
'

