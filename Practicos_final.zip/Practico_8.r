library(dplyr)
library(ggpubr)
library(car)
library(ez)

# Integrantes:
# - Ekaterina Cornejo 20.187.903-5
# - Catalina Y��ez 19.516.593-9
# - Aldo Castillo 19.839.621-4



# Problema A --------------------------------------------------------------


# Contexto

'
El siguiente c�digo R define los datos que aparecen en una tabla que compara las mejores soluciones encontradas
por cuatro algoritmos para instancias del problema del vendedor viajero con soluci�n �ptima conocida, tomados
desde una memoria del DIINF. Con estos datos responda la pregunta de investigaci�n: �Hay algoritmos mejores
que otros?
' 

texto <- ("
Instancia Optimo R R2 R3 G
'brock400_2' 29 16.6 19.3 20.2 22
'brock400_4' 33 16.8 19.3 20.4 22
'C2000.9' 80 51.2 59.6 62.4 66
'c-fat500-10' 126 125 125 125 126
'hamming10-2' 512 243.2 419.1 422.4 512
'johnson32-2-4' 16 16 16 16 16
'keller6' 59 34.5 43 45.5 48.2
'MANN_a81' 1100 1082.2 1082.2 1082.2 1095.9
'p-hat1500-1' 12 6.9 8.1 8.9 10
'p-hat1500-3' 94 42.8 77.7 84.6 86
'san1000' 15 7.6 7.6 7.7 10
'san400_0.7_1' 40 19.6 20.5 20.5 21
'san400_0.9_1' 100 44.1 54.4 56.4 92
'frb100-40' 100 66.4 76.7 80.5 82
'frb59-26-1' 59 39.2 45.9 48.3 48
'1et.2048' 316 232.4 268.4 280.9 292.4
'1zc.4096' 379 253.8 293.2 307.4 328.5
'2dc.2048' 24 15.6 18.7 19.9 21
")

datos <- read.table(textConnection(texto), header = TRUE)

# Hip�tesis
# Ur: Diferencia del resultado del algoritmo R contra su �ptimo
# Ur2: Diferencia del resultado del algoritmo R2 contra su �ptimo
# Ur3: Diferencia del resultado del algoritmo R3 contra su �ptimo
# Ug: Diferencia del resultado del algoritmo G contra su �ptimo

# H0: La diferencia es igual para los cuatro algoritmos. ( Ur = Ur2 = Ur3 = Ug )
# H1: La diferencia es distinta para al menos uno de los cuatro algoritmos. ( Ur != Ur2 != Ur3 != Ug )


# Verificaciones
# 1. La variable dependiente tiene escala de intervalos iguales.
# 2. Las mediciones son independientes al interior de cada grupo.
# 3. Se puede suponer razonablemente que la(s) poblaci�n(es) de origen sigue(n) una distribuci�n normal.
# 4. La matriz de varianzas-covarianzas es esf�ricas.


# 1. Se verifica la escala por intervalos iguales debido a que las soluciones tienen una escala decimal.

# 2. Se puede asumir independencia dentro de cada grupo debido al origen de los datos (Memoria DIINF).

# 3. Para suponer la distribuci�n normal de la poblaci�n de origen se realiza un gr�fico Q-Q.

R <- datos$R
R2 <- datos$R2
R3 <- datos$R3
G <- datos$G

solucion <- c(R,R2,R3,G)
instancias <- datos$Instancia

algoritmo <- c(rep("R",length(R)),
               rep("R2",length(R2)),
               rep("R3",length(R3)),
               rep("G",length(G)))

algoritmo <- factor(algoritmo)
instancia <- factor(instancias)
cuadro <- data.frame(instancia, algoritmo, solucion)

g <- ggqqplot(cuadro, x = "solucion", y = "algoritmo", color = "algoritmo")
g <- g + facet_wrap(~ algoritmo)
g <- g + rremove("x.ticks") + rremove("x.text")
g <- g + rremove("y.ticks") + rremove("y.text")
g <- g + rremove("axis.title")
print(g)


# Se puede decir que existen valores fuera de la distribuci�n, pero son la minor�a y se decide 
# no descartarlos para no afectar la independencia de la muestra. A�n as� presentan una 
# distribuci�n aproximadamente normal.

# 4. No se sabe si se cumple la condici�n de esfericidad, a�n cuando se cumple las dem�s condiciones,
# Se prosigue con mucha cautela, considerando un nivel de significaci�n alfa = 0,01.


# Al cumplirse las condiciones, se procede a aplicar ANOVA.


# Para encontrar el mejor algoritmo se necesita encontrar la menor distancia entre el 
# resultado obtenido y el �ptimo en cada instancia.

R.restado <- datos$Optimo - datos$R
R2.restado <- datos$Optimo - datos$R2
R3.restado <- datos$Optimo - datos$R3
G.restado <- datos$Optimo - datos$G

solucion2 <- c(R.restado, R2.restado, R3.restado, G.restado)
instancias2 <- datos$Instancia

algoritmo2 <- c(rep("R",length(R.restado)),
               rep("R2",length(R2.restado)),
               rep("R3",length(R3.restado)),
               rep("G",length(G.restado)))

algoritmo2 <- factor(algoritmo2)
instancia2 <- factor(instancias2)
cuadro2 <- data.frame(instancia2, algoritmo2, solucion2)


ez.aov <- ezANOVA(
  data = cuadro2, 
  dv = solucion2,
  within = algoritmo2,
  wid = instancia2,
  return_aov = TRUE
)
print(ez.aov)

cat("El resultado de la prueba de esfericidad de Mauchly:\n\n")
print(ez.aov$`Mauchly's Test for Sphericity`)

cat("\n\nY factores de correci�n para cuando no se cumple la\n")
cat("condici�n de esfericidad:\n\n")
print(ez.aov$`Sphericity Corrections`)


# Ya que el p-valor es de 0.006022434 que es menor a alfa de 0.01 se falla al aceptar H0 en favor
# a H1. No se cumple la condici�n de esfericidad por los resultados de la prueba de Mauchly's,
# usando las correcciones correspondientes el p-valor de nuestra prueba de ANOVA es p[HF] 
# igual a 0.04362063.

# Ya que el p-valor (p[HF]) es de 0.04362063 que es mayor a alfa de 0.01 no se rechaza H0. Por 
# lo que la diferencia es igual para los cuatro algoritmos. 


# An�lisis POST-HOC

holm <- pairwise.t.test(solucion2, algoritmo2, p.adj = "holm", paired = TRUE)
print(holm)

# Analizando la tabla de salida con el m�todo de post-hoc de Holm, ya que ning�n algoritmo
# tiene un p-valor menor a alfa de 0.01, no existe algoritmo mejor que otro.



