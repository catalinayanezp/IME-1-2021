library(readxl)
library(boot)
library(bootES)
library(simpleboot)
library(WRS2)
library(ggpubr)

# Integrantes:
# - Ekaterina Cornejo 20.187.903-5
# - Catalina Y��ez 19.516.593-9
# - Aldo Castillo 19.839.621-4



# Pr�ctico 10 20-06-21 --------------------------------------------------------------


# Parte 1 -----------------------------------------------------------------


# Se setea la direcci�n de trabajo en donde se encuentra nuestro archivo .R
dirstudio <- dirname(rstudioapi::getSourceEditorContext()$path)
setwd(dirstudio)

# Se guarda el nombre del archivo y se abre con File.path
basename <- "Datos-Casen-v2.xls"
file <- file.path(dirstudio, basename)

# Se lee el archivo .xls y se guarda en la variable "poblaci�n"
# poblaci�n <- read.csv(file = file, encoding = "UTF-8", quote = "")

poblacion <- read_xls(path = file, 1)

alfa <- 0.05

# Parte 2 -----------------------------------------------------------------


# a -----------------------------------------------------------------------

# h10c    C�digo para "�Tiene dificultad para caminar o para subir escaleras?"
# edad    C�digo para "Edad"


'
Us: Media de personas que no presentan dificultad al caminar o subir escaleras
Uc: Media de personas que si presentan mucha dificultad al caminar o subir escaleras

Se quiere saber la diferencia que existe entre la edad de personas que no tienen dificultad para caminar y personas que tienen mucha dificultad para caminar.

H0: Las personas que presentan dificultades para caminar tienen igual promedio de edad que las personas que no presentan dificultades (Us = Uc)
H1: Las personas que presentan dificultades para caminar NO tienen igual promedio de edad que las personas que no presentan dificultades (Us != Uc)
'


# b -----------------------------------------------------------------------

# ytotcorh    C�digo para "Ingreso total del hogar corregido"
# v1          C�digo para " �Cu�l es el tipo de vivienda que ocupa el entrevistado?"

'
Ua: Media de ingreso del hogar corregido en familias que viven en casas aisladas
Up1: Media de ingreso del hogar corregido en familias que viven en pareadas por un lado
Up2: Media de ingreso del hogar corregido en familias que viven en pareadas por ambos lados

Se quiere saber la diferencia que existe entre el total de ingreso del hogar (corregido) entre familias
que viven en casas aisladas, pareadas por un lado o pareadas por ambos lados.

H0: Las medias de todos los grupos familiares son iguales (Ua = Up1 = Up2)
H1: Al menos uno de los grupos familiares no es igual (Ua != Up1 != Up2)
'


# Parte 3 -----------------------------------------------------------------

set.seed(786867)

muestra <- poblacion[sample(1:65535, 499), ]


# Parte 4 -----------------------------------------------------------------

# Remuestreo a ------------------------------------------------------------

muestra.a.sin <- subset(muestra, muestra$h10c == "No, sin dificultad")
muestra.a.con <- subset(muestra, muestra$h10c == "S�, mucha dificultad")

media.a.sin <- mean(muestra.a.sin$edad)
media.a.con <- mean(muestra.a.con$edad)

valor_observado <- media.a.con - media.a.sin

media <- function(valores, i){mean(valores[i])}

B <- 9999
distribucion_bootstrap <- two.boot(muestra.a.con$edad, muestra.a.sin$edad, FUN = media, R = B)
valor_nulo <- 0
desplazamiento <- mean(distribucion_bootstrap[["t"]]) - valor_nulo
distribucion_nula <- distribucion_bootstrap[["t"]] - desplazamiento

p <- (sum(abs(distribucion_nula) > abs(valor_observado)) + 1) / (B + 1)
cat("Valor p: ", p)

valores <- data.frame(distribucion_bootstrap$t)
colnames(valores) <- "valores"

hist <- gghistogram(valores, 
                    x = "valores",
                    color = "red",
                    fill = "red",
                    bins = 100,
                    xlab = "Diferencia de medias",
                    ylab = "Frecuencia",
                    add = "mean")

print(hist)

qq <- ggqqplot(valores, 
               x = "valores",
               color = "red")

print(qq)


intervalo <- boot.ci(distribucion_bootstrap,
                     conf = 1 - alfa,
                     type = "bca")

print(intervalo)


# Conclusi�n

'
Se puede decir con un 95% de confianza que se rechaza H0 en favor de H1. La edad promedio entre personas que
no presentan dificultades al caminar o subir escaleras es distinta al promedio de edad de los que presentan
dificultades.
'

# Remuestreo b -------------------------------------------------------------


aislada <- subset(muestra, muestra$v1 == "Casa aislada (no pareada)")
pareada1 <- subset(muestra, muestra$v1 == "Casa pareada por un lado")
pareada2 <- subset(muestra, muestra$v1 == "Casa pareada por ambos lados")

ingreso.aislada <- aislada$ytotcorh
ingreso.pareada1 <- pareada1$ytotcorh
ingreso.pareada2 <- pareada2$ytotcorh

media.ingreso.aislada <- mean(ingreso.aislada)
media.ingreso.pareada1 <- mean(ingreso.pareada1)
media.ingreso.pareada2 <- mean(ingreso.pareada2)

# Se realizan todas las combinaciones y luego se comparan los p-valores
# (1) Casa aislada vs Casa pareada por un lado
# (2) Casa aislada vs Casa pareada por ambos lados
# (3) Casa pareada por un lado vs Casa pareada por ambos lados

valor_observado_1 <- media.ingreso.aislada - media.ingreso.pareada1
valor_observado_2 <- media.ingreso.aislada - media.ingreso.pareada2
valor_observado_3 <- media.ingreso.pareada1 - media.ingreso.pareada2

media <- function(valores, i){mean(valores[i])}
B <- 9999
valor_nulo <- 0

# Caso 1 ------------------------------------------------------------------


distribucion_bootstrap_1 <- two.boot(ingreso.aislada, ingreso.pareada1, FUN = media, R = B)
desplazamiento_1 <- mean(distribucion_bootstrap_1[["t"]]) - valor_nulo
distribucion_nula_1 <- distribucion_bootstrap_1[["t"]] - desplazamiento_1

p1 <- (sum(abs(distribucion_nula_1) > abs(valor_observado_1)) + 1) / (B + 1)


# Caso 2 ------------------------------------------------------------------


distribucion_bootstrap_2 <- two.boot(ingreso.aislada, ingreso.pareada2, FUN = media, R = B)
desplazamiento_2 <- mean(distribucion_bootstrap_2[["t"]]) - valor_nulo
distribucion_nula_2 <- distribucion_bootstrap_2[["t"]] - desplazamiento_2

p2 <- (sum(abs(distribucion_nula_2) > abs(valor_observado_2)) + 1) / (B + 1)


# Caso 3 ------------------------------------------------------------------


distribucion_bootstrap_3 <- two.boot(ingreso.pareada1, ingreso.pareada2, FUN = media, R = B)
desplazamiento_3 <- mean(distribucion_bootstrap_3[["t"]]) - valor_nulo
distribucion_nula_3 <- distribucion_bootstrap_3[["t"]] - desplazamiento_3

p3 <- (sum(abs(distribucion_nula_3) > abs(valor_observado_3)) + 1) / (B + 1)


# An�lisis ----------------------------------------------------------------
# Se comparan los p-valores de todas las combinaciones

cat("                                                             P-valor")
cat("Casa aislada vs Casa pareada por un lado:                  ", p1)
cat("Casa aislada vs Casa pareada por ambos lados:              ", p2)
cat("Casa pareada por un lado vs Casa pareada por ambos lados:  ", p3)


# Conclusi�n

'
Aplicando bootstrap para la diferencia de medias en cada combinaci�n posible entre los grupos y 
comparando sus p-valores, se puede decir que se rechaza H0 en favor de H1, ya que existe al menos
un grupo cuya media de ingreso familiar corregido no es igual a las dem�s (p-valores 0.006 y 0.0086
menores a alfa 0.05).
'

# M�todo robusto a --------------------------------------------------------

muestra.a.sin <- subset(muestra, muestra$h10c == "No, sin dificultad")
muestra.a.con <- subset(muestra, muestra$h10c == "S�, mucha dificultad")

edad.a.sin <- muestra.a.sin$edad
edad.a.con <- muestra.a.con$edad

edades <- c(edad.a.sin, edad.a.con)
dificultad <- c(rep("Sin dificultad", length(edad.a.sin)),
                rep("Con dificultad", length(edad.a.con)))

datos <- data.frame(edades, dificultad)

g <- ggqqplot(datos,
              x = "edades",
              facet.by = "dificultad",
              palette = c("blue", "red"),
              color= "dificultad")
print(g)

alfa <- 0.05

gamma <- 0.2

n_sin <- length(edad.a.sin)
n_con <- length(edad.a.con)

poda_sin <- n_sin * gamma
poda_con <- n_con * gamma

sin_truncada <- edad.a.sin[poda_sin:(n_sin - poda_sin)]
con_truncada <- edad.a.con[poda_con:(n_con - poda_con)]

edades2 <- c(sin_truncada, con_truncada)
dificultad2 <- c(rep("Sin dificultad (truncada)", length(sin_truncada)),
                 rep("Con dificultad (truncada)", length(con_truncada)))

datos_truncados <- data.frame(edades2, dificultad2)

g2 <- ggqqplot(datos_truncados,
              x = "edades2",
              facet.by = "dificultad2",
              palette = c("blue", "red"),
              color= "dificultad2")
print(g2)

prueba <- yuen(edades2 ~ dificultad2,
               data = datos_truncados,
               tr = gamma)
print(prueba)

# Conclusi�n

'
Debido a que nuestro p valor es de 0.04145, lo que es levemente menor a alfa 0.05, se rechaza
H0 en favor a H1. Las edades promedio de las personas sin dificultad es distinta a la edad promedio
de las personas con dificultad de caminar o subir escaleras.
'

# M�todo Robusto b -------------------------------------------------------------

aislada <- subset(muestra, muestra$v1 == "Casa aislada (no pareada)")
pareada1 <- subset(muestra, muestra$v1 == "Casa pareada por un lado")
pareada2 <- subset(muestra, muestra$v1 == "Casa pareada por ambos lados")

ingreso.aislada <- aislada$ytotcorh
ingreso.pareada1 <- pareada1$ytotcorh
ingreso.pareada2 <- pareada2$ytotcorh

ingresos <- c(ingreso.aislada, ingreso.pareada1, ingreso.pareada2)
tipo_casa <- c(rep("Casa aislada", length(ingreso.aislada)),
                  rep("Casa pareada por un lado", length(ingreso.pareada1)),
                  rep("Casa pareada por ambos lados", length(ingreso.pareada2)))

datos <- data.frame(ingresos, tipo_casa)

alfa <- 0.05

set.seed(11405)

media_truncada <- t1waybt(ingresos ~ tipo_casa,
                          data = datos,
                          tr = 0.2,
                          nboot = 999)

print(media_truncada)

# Debido a que nuestro p-valor es de 0.002 que es menor a alfa 0.05 se aplica
# procedimiento post-hoc

post_hoc <- mcppb20(ingresos ~ nacionalidad,
                    data = datos,
                    tr = 0.2,
                    nboot = 999)

print(post_hoc)

#Conclusi�n 

'
Al efectuar los procedimientos post-hoc correspondientes, se puede ver los dos p-valores
que involucran "Casa pareada por un lado" son menores a alfa 0.05. Esto quiere decir que se
rechaza H0 en favor de H1. Existe al menos una media de ingreso distinta seg�n los tipos de casa.
'