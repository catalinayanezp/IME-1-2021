#Ejercicio pr�ctico 8

# Integrantes:
# - Ekaterina Cornejo 20.187.903-5
# - Catalina Y��ez 19.516.593-9
# - Aldo Castillo 19.839.621-4



# Pregunta A --------------------------------------------------------------

'
Contexto: 

El siguiente c�digo R define los datos que aparecen en una tabla que compara las 
mejores soluciones encontradas por cuatro algoritmos para instancias del problema 
del vendedor viajero con soluci�n �ptima conocida, tomados desde una memoria del 
DIINF. Con estos datos responda la pregunta de investigaci�n: �Hay algoritmos 
mejores que otros?

'


texto <- ("
Instancia Optimo R R2 R3 G
'brock400_2' 29 16.6 19.3 20.2 22
'brock400_4' 33 16.8 19.3 20.4 22
'C2000.9' 80 51.2 59.6 62.4 66
'c-fat500-10' 126 125 125 125 126
'hamming10-2' 512 243.2 419.1 422.4 512
'johnson32-2-4' 16 16 16 16 16
'keller6' 59 34.5 43 45.5 48.2
'MANN_a81' 1100 1082.2 1082.2 1082.2 1095.9
'p-hat1500-1' 12 6.9 8.1 8.9 10
'p-hat1500-3' 94 42.8 77.7 84.6 86
'san1000' 15 7.6 7.6 7.7 10
'san400_0.7_1' 40 19.6 20.5 20.5 21
'san400_0.9_1' 100 44.1 54.4 56.4 92
'frb100-40' 100 66.4 76.7 80.5 82
'frb59-26-1' 59 39.2 45.9 48.3 48
'1et.2048' 316 232.4 268.4 280.9 292.4
'1zc.4096' 379 253.8 293.2 307.4 328.5
'2dc.2048' 24 15.6 18.7 19.9 21
")
datos <- read.table(textConnection(texto), header = TRUE)


# Desarrollo

# Condiciones a verificar:
# 
# 1. La escala con que se mide la variable dependiente tiene las propiedades de 
# una escala de intervalos iguales.
#
# 2. Las mediciones son independientes al interior de cada grupo.
#
# 3. Se puede suponer razonablemente que la(s) poblaci�n(es) de origen sigue(n) 
# una distribuci�n normal.
#
# 4. La matriz de varianzas-covarianzas es esf�rica.

# La primera condici�n se cumple ya que para las soluciones se utilizan los n�meros
# racionales, que tienen una escala constante, y en este caso las soluciones se
# representan con diferencias en d�cimas.