library(car)


# Integrantes:
# - Ekaterina Cornejo 20.187.903-5
# - Catalina Y��ez 19.516.593-9
# - Aldo Castillo 19.839.621-4


# Se setea la direcci�n de trabajo en donde se encuentra nuestro archivo .R
dirstudio <- dirname(rstudioapi::getSourceEditorContext()$path)
setwd(dirstudio)

# Se guarda el nombre del archivo y se abre con File.path
basename <- "Phishing.csv"
file <- file.path(dirstudio, basename)

datos.todos <- read.csv(
  file = file,
  sep = ","
)

set.seed(199905)


# Se selecciona una muestra de 500 datos de casos al azar

muestra <- sample(nrow(datos.todos), 500)
entrenamiento <- datos.todos[muestra, ]
prueba <- datos.todos[-muestra,]

# Ajustar modelo completo

completo <- glm(Page_Rank ~ ., data = entrenamiento)
nulo <- glm(Page_Rank ~ 1, data = entrenamiento)

auto1 <- step(nulo, scope = list(upper = completo), direction = "forward")
print(AIC(auto1))

auto2 <- step(auto1, scope = list(upper = nulo), direction = "backward")
print(summary(auto2))
print(AIC(auto2)) #1223.016

# Ya que se encontr� poco significativa, se borra la variable Google_Index

entrenamiento$Google_Index <- NULL
entrenamiento$having_At_Symbol <- NULL
entrenamiento$Links_in_tags <- NULL
entrenamiento$Prefix_Suffix <- NULL

completo <- glm(Page_Rank ~ ., data = entrenamiento)
nulo <- glm(Page_Rank ~ 1, data = entrenamiento)

auto1 <- step(nulo, scope = list(upper = completo), direction = "forward")
print(AIC(auto1))

auto2 <- step(auto1, scope = list(upper = nulo), direction = "backward")
print(summary(auto2))
print(AIC(auto2)) #1226.04



# Condiciones:
# 1) Independencia del error (residuos)

print(durbinWatsonTest(auto2, max.lag = 8))

# Con la prueba de Durbin Watson se puede notar que no existe autocorrelaci�n 
# entre las variables

# 2) Residuos con distribuci�n normal
# 3) Homocedasticidad

# Se asume que los residuos tienen distribuci�n normal y que los residuos de 
# cada nivel de cada variable predictora tienen aproximadamente la misma varianza

# 4) Multicolinealidad

vifs <- vif(auto2)
print(round(vifs, 1))

# Se pueden observar valores de VIFS v�lidos

# Ahora se debe ver el poder predictivo de este modelo

# Calcular error cuadrado promedio para el conjunto de entrenamiento

mse_entrenamiento <- mean(auto2$residuals ** 2)
cat ("MSE para el conjunto de entrenamiento: " , mse_entrenamiento, "\n")

predicciones <- predict ( auto2 , prueba )


# Calcular error cuadrado promedio para el conjunto de prueba

error <- prueba [["Page_Rank"]] - predicciones
mse_prueba <- mean(error ** 2)
cat ("MSE para el conjunto de prueba: " , mse_prueba)

# Conclusi�n

# Como se puede notar, el error cambia poco (0.03658981) entre el conjunto de 
# entrenamiento (MSE = 0.6532488) y el de prueba (MSE = 0.6898386). Esto quiere
# decir que el modelo se adapta bien a ambos conjuntos, los de entrenamiento y 
# prueba, por lo que el modelo se se puede suponer como generalizado.

