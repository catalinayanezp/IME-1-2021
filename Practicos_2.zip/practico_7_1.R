library(car)
library(mosaic)
library(pander)
library(tidyverse)


chick.aov <- aov(weight ~ feed, data=chickwts)
summary(chick.aov) %>% pander()