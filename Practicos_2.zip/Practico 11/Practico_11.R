
# Integrantes:
# - Ekaterina Cornejo 20.187.903-5
# - Catalina Y��ez 19.516.593-9
# - Aldo Castillo 19.839.621-4


# Se setea la direcci�n de trabajo en donde se encuentra nuestro archivo .R
dirstudio <- dirname(rstudioapi::getSourceEditorContext()$path)
setwd(dirstudio)

# Se guarda el nombre del archivo y se abre con File.path
basename <- "body.csv"
file <- file.path(dirstudio, basename)

datos.todos <- read.csv(
  file = file,
  sep = ";"
)


# Parte 1 -----------------------------------------------------------------

set.seed(199801)


# Debido a la falta de informaci�n se asume 1 como hombre

filtro <- which(datos.todos[["Gender"]] == 1)

filtro <- sample(filtro, 50)
muestra <- datos.todos[filtro, ]



# Parte 2 -----------------------------------------------------------------

# Ajustar modelo completo
completo <- lm(Height ~ ., data = muestra)

# Ajustar modelo nulo
nulo <- lm(Height ~ 1, data = muestra)

# Ajustar modelo con eliminaci�n hacia atr�s
atras <- step(completo, scope = list(lower = nulo),
              direction = "backward",
              trace = 0)

print(summary(atras))
cat("AIC =", AIC(atras), "\n\n")

##################################################################

# Luego de analizar el resultado se eliminan las columnas correspondientes
# Chest.depth
# Ankles.diameter
# Ankle.Minimum.Girth

# En primer lugar, se elimina la columna Chest.depth

muestra2 <- muestra
muestra2$Chest.depth <- NULL

# Ajustar modelo completo
completo <- lm(Height ~ ., data = muestra2)
# Ajustar modelo nulo
nulo <- lm(Height ~ 1, data = muestra2)

# Ajustar modelo con eliminaci�n hacia atr�s
atras <- step(completo, scope = list(lower = nulo),
              direction = "backward",
              trace = 0)

print(summary(atras))
cat("AIC =", AIC(atras), "\n\n")

##################################################################

# Luego, se elimina la columna Ankles.diameter


muestra3 <- muestra2
muestra3$Ankles.diameter <- NULL

# Ajustar modelo completo
completo <- lm(Height ~ ., data = muestra3)
# Ajustar modelo nulo
nulo <- lm(Height ~ 1, data = muestra3)

# Ajustar modelo con eliminaci�n hacia atr�s
atras <- step(completo, scope = list(lower = nulo),
              direction = "backward",
              trace = 0)

print(summary(atras))
cat("AIC =", AIC(atras), "\n\n")


##################################################################

# Finalmente, se elimina la columna Ankle.Minimum.Girth

muestra4 <- muestra2
muestra4$Ankle.Minimum.Girth <- NULL

# Ajustar modelo completo
completo <- lm(Height ~ ., data = muestra4)
# Ajustar modelo nulo
nulo <- lm(Height ~ 1, data = muestra4)

# Ajustar modelo con eliminaci�n hacia atr�s
atras <- step(completo, scope = list(lower = nulo),
              direction = "backward",
              trace = 0)

print(summary(atras))
cat("AIC =", AIC(atras), "\n\n")


# Seg�n los resultados antes observados, se tiene que el mejor AIC se obtiene 
# al eliminar la columna Chest.depth, por lo que se ocupa la muestra 2.


# Parte 3 -----------------------------------------------------------------

# Para asegurarse de ocupar datos no utilizados anteriormente, se genera un 
# nuevo filtro, pero esta vez con Gender = 0 (Mujeres)

filtro2 <- which(datos.todos[["Gender"]] == 0)

filtro2 <- sample(filtro2, 50)
prueba <- datos.todos[filtro2, ]


# Calcular error cuadrado promedio para el conjunto de entrenamiento
mse_entrenamiento <- mean(atras$residuals ** 2)
cat ("MSE para el conjunto de entrenamiento: " , mse_entrenamiento, "\n")

predicciones <- predict ( atras , prueba )


# Calcular error cuadrado promedio para el conjunto de prueba
error <- prueba [["Height"]] - predicciones
mse_prueba <- mean(error ** 2)
cat ("MSE para el conjunto de prueba: " , mse_prueba)

# Conclusi�n

# Como se puede notar, el error cambia considerablemente entre el conjunto de 
# entrenamiento (MSE = 12.04091) y el de prueba (MSE = 36.32733). Esto quiere 
# decir que el modelo probablemente se adapta bien al conjunto de entrenamiento 
# pero no al de prueba, por lo que el modelo no se podr�a suponer como generalizado.

