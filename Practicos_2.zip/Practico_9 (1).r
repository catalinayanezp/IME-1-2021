library(dplyr)
library(ggpubr)
library(car)
library(rcompanion)
library(ez)

# Integrantes:
# - Ekaterina Cornejo 20.187.903-5
# - Catalina Y��ez 19.516.593-9
# - Aldo Castillo 19.839.621-4



# Pr�ctico 9 12-06-21 --------------------------------------------------------------


# Problema B --------------------------------------------------------------

# Contexto

'
El siguiente texto muestra los resultados de clasificadores en diferentes instancias de prueba disponibles 
en el repositorio UCI. Los algoritmos corresponden a C1: J48 decision tree, C3: averaged one-dependence 
estimator (AODE), C5: J48 graft, C6: locally weighted naive-Bayes y C7: random forest. �Existe un algoritmo, 
o un grupo de algoritmos, mejor que otro(s)?
'

texto <-("Dataset C1 C3 C5 C6 C7
'credit' 84.93 85.07 84.93 85.22 83.33
'eucalyptus' 64.28 58.71 64.01 59.52 59.40
'glass' 71.58 73.83 71.10 75.69 73.33
'hepatitis' 79.46 83.79 79.46 82.50 81.25
'hungarian-14' 78.64 84.39 78.64 84.38 81.97
'hypothyroid' 99.28 98.54 99.28 98.62 98.97
'iris' 93.33 92.67 93.33 92.00 93.33
'mushroom' 100.00 99.95 100.00 99.84 100.00
'optdigits' 78.97 96.90 81.01 94.20 91.80
'page-blocks' 96.62 96.95 96.66 94.15 96.97
'pendigits' 89.05 97.82 89.87 94.81 95.67
'pima-diabetes' 73.70 75.01 73.56 74.75 72.67
'primary-tumor' 40.11 47.49 40.11 49.55 38.31
'solar-flare-C' 88.86 88.54 88.86 87.92 86.05
'solar-flare-m' 90.10 87.92 90.10 86.99 85.46
'solar-flare-X' 97.84 97.84 97.84 94.41 95.99
'sonar' 74.48 81.26 74.45 80.79 78.36
'waveform' 74.38 84.92 74.90 83.62 79.68
'yeast' 57.01 56.74 57.01 57.48 56.26
")

datos <- read.table(textConnection(texto), header = TRUE)

# Hip�tesis
# Uc1: Diferencia del resultado del algoritmo C1 contra su �ptimo
# Uc3: Diferencia del resultado del algoritmo C3 contra su �ptimo
# Uc5: Diferencia del resultado del algoritmo C5 contra su �ptimo
# Uc6: Diferencia del resultado del algoritmo C6 contra su �ptimo
# Uc7: Diferencia del resultado del algoritmo C7 contra su �ptimo

# H0: La diferencia es igual para los cuatro algoritmos. ( Uc1 = Uc3 = Uc5 = Uc6 = Uc7 )
# H1: La diferencia es distinta para al menos uno de los cinco algoritmos. ( Uc1 != Uc3 != Uc5 != Uc6 != Uc7 )


# Condiciones a verificar
# 1. La variable dependiente tiene escala de intervalos iguales.
# 2. Las mediciones son independientes al interior de cada grupo.
# 3. Se puede suponer razonablemente que la(s) poblaci�n(es) de origen sigue(n) una distribuci�n normal.
# 4. La matriz de varianzas-covarianzas es esf�ricas.


# 1. Se verifica la escala por intervalos iguales debido a que las soluciones tienen una escala decimal.

# 2. Se puede asumir independencia dentro de cada grupo debido al origen de los datos (Repositorio UCI).

# 3. Para suponer la distribuci�n normal de la poblaci�n de origen se realiza un gr�fico.


C1 <- datos$C1
C3 <- datos$C3
C5 <- datos$C5
C6 <- datos$C6
C7 <- datos$C7

solucion <- c(C1,C3,C5,C6,C7)
instancias <- datos$Dataset

algoritmo <- c(rep("C1",length(C1)),
               rep("C3",length(C3)),
               rep("C5",length(C5)),
               rep("C6",length(C6)),
               rep("C7",length(C7)))

algoritmo <- factor(algoritmo)
instancia <- factor(instancias)

cuadro <- data.frame(instancia, algoritmo, solucion)


g1 <- ggscatter(cuadro, 
               x = "solucion", 
               y = "algoritmo", 
               color = "blue", 
               xlab = "solucion", 
               ylab = "algoritmo")
print(g1)

g2 <- gghistogram(cuadro,
                       x = "solucion",
                       bins = 10,
                       xlab = "solucion",
                       ylab = "algoritmo",
                       color = "red",
                       fill = "red")
print(g2)


# Debido a que no presentan distribucion normal se aplica la transformaci�n de Tukey, ya que
# cumple las mismas condiciones que la transformaci�n logar�tmica, pero es menos especifica.


lambda_menos_dos <- 1 / (cuadro$solucion ** -2)
lambda_menos_uno <- 1 / (cuadro$solucion ** -1)
lambda_menos_un_medio <- 1 / (cuadro$solucion ** -0.5)
lambda_un_medio <- sqrt(cuadro$solucion)
lambda_dos <- (cuadro$solucion ** 2)

transformaciones <- data.frame(cuadro, lambda_menos_dos, 
                               lambda_menos_uno, 
                               lambda_menos_un_medio, 
                               lambda_un_medio, 
                               lambda_dos)

gt1 <- ggscatter(transformaciones, 
                 x = "solucion", 
                 y = "lambda_menos_dos", 
                 color = "blue", 
                 xlab = "solucion", 
                 ylab = "lambda = - 2") + rotate_x_text(45)

gt2 <- ggscatter(transformaciones, 
                 x = "solucion", 
                 y = "lambda_menos_uno", 
                 color = "blue", 
                 xlab = "solucion", 
                 ylab = "lambda = - 1") + rotate_x_text(45)


gt3 <- ggscatter(transformaciones, 
                 x = "solucion", 
                 y = "lambda_menos_un_medio", 
                 color = "blue", 
                 xlab = "solucion", 
                 ylab = "lambda = - 0.5") + rotate_x_text(45)

gt4 <- ggscatter(transformaciones, 
                 x = "solucion", 
                 y = "lambda_un_medio", 
                 color = "blue", 
                 xlab = "solucion", 
                 ylab = "lambda = 0.5") + rotate_x_text(45)

gt5 <- ggscatter(transformaciones, 
                 x = "solucion", 
                 y = "lambda_dos", 
                 color = "blue", 
                 xlab = "solucion", 
                 ylab = "lambda = 2") + rotate_x_text(45)

dispersion <- ggarrange(gt1, gt2, gt3, gt4, gt5, ncol = 3, nrow = 2)
texto <- "Solucion transformada por algoritmo"
titulo <- text_grob(texto,
                    face = "bold",
                    size = 14)
dispersion <- annotate_figure(dispersion, top = titulo)
print(dispersion)

transformacion <- transformTukey(cuadro$solucion,
                                 start = -4,
                                 end = 4,
                                 int = 0.001,
                                 returnLambda = TRUE)


# Segun la funci�n transformTukey el lambda �ptimo es de 3.237, por lo que se calcula la
# la transformaci�n con este lambda para poder aplicar anova.

lambda_optimo <- cuadro$solucion ** 3.237

transformacion_optima <- data.frame(cuadro, lambda_optimo)

gto <- ggscatter(transformacion_optima, 
                 x = "solucion", 
                 y = "lambda_optimo", 
                 color = "blue", 
                 xlab = "solucion", 
                 ylab = "lambda = 3.237") + rotate_x_text(45)

print(gto)

hto <- gghistogram(transformacion_optima,
                   x = "lambda_optimo",
                   bins = 10,
                   color = "blue", 
                   fill = "blue", 
                   xlab = "lambda = 3.237") + rotate_x_text(45)

print(hto)


# Con los datos ya transformados podemos aplicar anova.


# 4. No se sabe si se cumple la condici�n de esfericidad, a�n cuando se cumple las dem�s condiciones,
# Se prosigue con mucha cautela, considerando un nivel de significaci�n alfa = 0,01.

# Al cumplirse las condiciones, se procede a aplicar ANOVA.


# Para encontrar el mejor algoritmo se necesita encontrar la menor distancia entre el 
# resultado obtenido y el �ptimo en cada instancia.


ez.aov <- ezANOVA(
  data = transformacion_optima, 
  dv = lambda_optimo,
  within = algoritmo,
  wid = instancia,
  return_aov = TRUE
)
print(ez.aov)

cat("El resultado de la prueba de esfericidad de Mauchly:\n\n")
print(ez.aov$`Mauchly's Test for Sphericity`)

cat("\n\nY factores de correci�n para cuando no se cumple la\n")
cat("condici�n de esfericidad:\n\n")
print(ez.aov$`Sphericity Corrections`)



# Ya que el p-valor es de 1.479e-24, que es menor a alfa de 0.01, se falla al aceptar H0 en favor
# a H1. No se cumple la condici�n de esfericidad por los resultados de la prueba de Mauchly's,
# usando las correcciones correspondientes el p-valor de nuestra prueba de ANOVA es p[HF] 
# igual a 0.0682

# Ya que el p-valor (p[HF]) es de 0.0682 que es mayor a alfa de 0.01 no se rechaza H0. Por 
# lo que la diferencia es igual para los cinco algoritmos.


# Problema C --------------------------------------------------------------

# Contexto


'
En trabajo de t�tulo de un estudiante del DIINF, se reportan los siguientes tiempos de ejecuci�n (Tpo en milisegundos)
medidos para dos versiones de un algoritmo gen�tico (A6 y B12) para resolver instancias del problema del vendedor
viajero disponibles en repositorios p�blicos. �Es uno de los algoritmos m�s r�pido que el otro?
'

texto <-("
Instancia 'Tpo A6' 'Tpo B12'
'rat575' 33349 32444
'u724' 55026 64019
'd657' 43352 52696
'rat783' 65076 76857
'u574' 112326 123456
'pr1002' 136262 162808
'fl1577' 3234574 3192222
'nrw1379' 335608 393213
'd1291' 268964 335566
'u1432' 398653 472597
'pcb1173' 303634 234658
'fl1400' 337977 430748
'u2152' 3073534 3253423
'rl1323' 243679 132654
'rl1304' 342321 231254
'u1817' 876432 672542
'vm1084' 413672 543215
'rl1889' 1876432 854213
'pr2392' 6764986 8765321
'u1060' 3453176 432876
")

datos <- read.table(textConnection(texto), header = TRUE)

# Ua6: Media de tiempo del algoritmo A6
# Ub12: Media de tiempo del algoritmo b12

# H0: Los dos algoritmos tienen la misma media de tiempo de ejecuci�n (Ua6 = Ub12)
# H1: Los dos algoritmos NO tienen la misma media de tiempo de ejecuci�n (Ua6 != Ub12)

# Se aplica la prueba de suma de rangos de Wilcoxon ya que es la alternativa no param�trica
# a la prueba de t-student con muestras independientes.

# Se verifican las condiciones correspondientes:

# Condiciones:
# 1.- Las observaciones son independientes
# 2.- La escala de medici�n empleada debe ser a lo menos ordinal


# 1.- Se asume independencia por enunciado
# 2.- Los valores dentro de las muestras se pueden ordenar con relaciones de mayor, menor o igual.
#     Por ejemplo 43352 es menor que 55026 y mayor que 33349.

muestra_A6 <- datos$Tpo.A6
muestra_B12 <- datos$Tpo.B12

alfa = 0.05

prueba <- wilcox.test(muestra_A6, muestra_B12, alternative = "two.sided", conf.level = 1 - alfa)
print(prueba)


# Ya que el p-valor es de 0.9 y nuestro alfa es de 0.05, no se rechaza H0 en favor de H1. Existe
# suficiente material estad�stico para decir que no hay mayores diferencias entre los tiempos de 
# ejecuci�n de ambos algoritmos.

# Problema F --------------------------------------------------------------

# Contexto


'
Contexto:

Una compa��a de cosm�ticos hizo una prueba preliminar de su nueva crema quitamanchas, en que 30 personas fueron
separadas aleatoriamente en tres grupos de 10 voluntarios/as: uno de control, a quienes se les entreg� una crema placebo
(humectante solamente); otro que usaron la crema quitamanchas que la compa��a comercializa actualmente; y el �ltimo
que usaron el nuevo producto. A todos se les dijo que usaban la crema nueva de �ltima generaci�n. Dos personas del 
grupo de control y una del grupo con la crema existente abandonaron el estudio. Para el resto, se reportaron los siguientes
n�meros de manchas removidas al finalizar el tiempo de prueba:
'

#U1: Media de muestras del grupo nueva
#U2: Media de muestras del grupo actual
#U3: Media de muestras del grupo control

#H0: Todos los grupos presentan resultados similares en cuanto a la disminuci�n de manchas en la piel (U1 = U2 = U3)
#H1: Al menos uno de los grupos presenta resultados diferentes al resto en cuanto a la disminuci�n de manchas. (U1 != U2 != U3)

texto <-("
Nueva Actual Control
81 48 18
32 31 49
42 25 33
62 22 19
37 30 24
44 30 17
38 32 48
47 15 22
49 40 --
41 -- --
")

# Construir la mariz de datos .
nueva<- c(81,32,42,62,37,44,38,47,49,41)
actual<- c(48,31,25,22,30,30,32,15,40)
control<- c(18,49,33,19,24,17,48,22)
manchas<-c(nueva,actual,control)
grupo<-c(rep("nueva",length(nueva)),
         rep("actual",length(actual)),
         rep("control",length(control)))

grupo<-factor(grupo)

datos<-data.frame(manchas,grupo)

# Establecer nivel de significaci�n
alfa <- 0.01

# Hacer la prueba de Kruskal-Wallis
prueba<-kruskal.test(manchas~grupo,data=datos )
print(prueba)

# Efectuar procedimiento post-hoc de Holm si se encuentran diferencias
# significativas
if(prueba$p.value<alfa) {
  post_hoc<-pairwise.wilcox.test(datos$manchas ,
                                 datos$grupo ,
                                 p.adjust.method = "holm",
                                 paired = FALSE )
  
  print(post_hoc)
}

#Considerando un nivel de significaci�n alfa = 0.01, se puede concluir con 99 % 
#de confianza que no existen diferencias significativas entre el n�mero 
#de manchas en la piel promedio de cada uno de los grupos estudiados.


